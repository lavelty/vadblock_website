// Theme loading
chrome.storage.local.get({ theme: 'default' }, (r) => {
    document.body.setAttribute('data-theme', r.theme);
});

document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('openOptions');
    if (btn) {
        btn.addEventListener('click', () => {
            if (chrome.runtime && chrome.runtime.openOptionsPage) {
                chrome.runtime.openOptionsPage();
            } else {
                window.open('html/options.html');
            }
        });
    }

    // "Neler Yeni" → vadblock.com/whats-new
    const whatsNewBtn = document.getElementById('openWhatsNew');
    if (whatsNewBtn) {
        whatsNewBtn.addEventListener('click', () => {
            if (chrome.tabs && chrome.tabs.create) {
                chrome.tabs.create({ url: 'https://vadblock.com/whats-new' });
            } else {
                window.open('https://vadblock.com/whats-new');
            }
        });
    }

    // Hesap durumuna göre rozeti güncelle
    const badge = document.getElementById('welcomeAccountBadge');
    if (badge && chrome.storage) {
        chrome.storage.local.get({ vadblockToken: null }, (r) => {
            if (r.vadblockToken) {
                badge.textContent = '✓ Hesabın bağlı';
            } else {
                badge.textContent = '✨ Ücretsiz · tüm özellikler açık';
                badge.style.cursor = 'pointer';
                badge.title = 'Hesap oluşturmak için tıkla';
                badge.addEventListener('click', () => {
                    if (chrome.runtime && chrome.runtime.openOptionsPage) chrome.runtime.openOptionsPage();
                    else window.open('html/options.html');
                });
            }
        });
    }
});
