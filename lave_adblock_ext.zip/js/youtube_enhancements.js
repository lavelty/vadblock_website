// youtube_enhancements.js
(function() {
    'use strict';
    let hideShorts = false;
    let deClickbait = false;

    chrome.storage.local.get({ settings: {} }, (r) => {
        hideShorts = (r.settings || {}).hideYtShorts === true;
        deClickbait = (r.settings || {}).deClickbait === true;
        
        if (hideShorts) {
            const style = document.createElement('style');
            style.textContent = `
                ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts]),
                ytd-reel-shelf-renderer,
                ytd-mini-guide-entry-renderer[title="Shorts"],
                ytd-guide-entry-renderer:has(a[title="Shorts"]) {
                    display: none !important;
                }
            `;
            (document.head || document.documentElement).appendChild(style);
        }

        if (deClickbait) {
            const observer = new MutationObserver(() => {
                document.querySelectorAll('#video-title, .yt-core-attributed-string').forEach(el => {
                    const text = el.textContent || '';
                    if (text === text.toUpperCase() && text.length > 15 && /[A-Z]/.test(text)) {
                        el.textContent = text.charAt(0) + text.slice(1).toLowerCase();
                        el.setAttribute('data-vadblock-declickbait', '1');
                    }
                });
            });
            observer.observe(document.documentElement, { childList: true, subtree: true });
        }
    });
})();
