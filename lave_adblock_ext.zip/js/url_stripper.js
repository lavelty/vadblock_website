﻿// url_stripper.js - İzleme Parametrelerini Temizleyici
(() => {
    'use strict';
    const params = new URLSearchParams(window.location.search);
    const trackingParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid', 'igshid', '_gl', '_ga', 'mc_eid', 'yclid', 'msclkid'];
    let modified = false;
    
    trackingParams.forEach(param => {
        if (params.has(param)) {
            params.delete(param);
            modified = true;
        }
    });

    if (modified) {
        let newUrl = window.location.pathname;
        let search = params.toString();
        if (search) newUrl += '?' + search;
        if (window.location.hash) newUrl += window.location.hash;
        window.history.replaceState({}, document.title, newUrl);
        console.log('[vAdBlock] Tracking parameters stripped from URL.');
    }
})();
