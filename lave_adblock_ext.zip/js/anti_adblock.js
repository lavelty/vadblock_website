// anti_adblock.js — "reklam engelleyici tespit edildi" duvarlarini gizler.
// GÜVENLİ MOD: Yalnızca gerçek overlay/duvar görünümündeki elementler gizlenir.
// Sayfa içeriği (nav, hero, butonlar, metinler) asla gizlenmez — yanlış pozitifleri önler.
(() => {
  'use strict';

  // Güçlü duvar ifadeleri — sıradan "adblock" sözcüğü geçen metinler eşleşmez.
  const STRONG_WALL = /reklam engelleyici(?:yi|niz|sini)? (?:tespit|kapat|devre|engel)|ad ?block(?:er)? (?:detected|engel|wall|tespit)|ad ?blocking (?:detected|engel)|please (?:disable|turn off|whitelist).{0,40}(?:ad ?block|reklam)|disable.{0,40}(?:ad ?block|reklam engelleyici)|var is checking|disable for futbin|red card for ad blocking|allow (?:ads|reklam).{0,20}(?:site|whitelist)|whitelist.{0,20}(?:us|this site|site)|(?:enable|whitelist) (?:ads|reklamlar)/i;

  // Overlay görünümünde mi? (fixed/absolute/sticky konum, yüksek z-index veya dialog)
  function looksLikeOverlay(el) {
    const cs = window.getComputedStyle(el);
    const pos = cs.position;
    if (pos === 'fixed' || pos === 'absolute' || pos === 'sticky') return true;
    const z = parseInt(cs.zIndex, 10);
    if (!isNaN(z) && z >= 90) return true;
    if (el.getAttribute('role') === 'dialog' || el.getAttribute('aria-modal') === 'true') return true;
    return false;
  }

  function hideWall(el) {
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('data-vadblock-hidden', '1');
    if (document.body) document.body.style.setProperty('overflow', 'auto', 'important');
    if (document.documentElement) document.documentElement.style.setProperty('overflow', 'auto', 'important');
  }

  // Duvarı bul: metin eşleşen elementten yukarı çık, ancak yalnızca overlay görünümlü bir
  // ata gizlenebilir. Sayfa akışındaki normal içerik asla gizlenmez.
  function findWallTarget(el) {
    let target = el;
    let depth = 0;
    while (target && target.parentElement && target.parentElement.tagName !== 'BODY' && target.parentElement.tagName !== 'HTML' && target.parentElement.id !== 'root' && target.parentElement.id !== '__next' && target.parentElement.id !== 'app' && depth < 5) {
      target = target.parentElement;
      depth++;
    }
    // Ataları tek tek kontrol et — en dıştaki overlay'e kadar
    let cur = el;
    while (cur && cur !== document.body) {
      if (looksLikeOverlay(cur) && !cur.getAttribute('data-vadblock-hidden')) {
        return cur;
      }
      cur = cur.parentElement;
    }
    if (looksLikeOverlay(target) && !target.getAttribute('data-vadblock-hidden')) {
      return target;
    }
    return null;
  }

  function scan() {
    // 1. Admiral Image bypass (yalnızca overlay görünümlü ata gizlenir)
    const admiralImgs = document.querySelectorAll('img[src*="getadmiral.com"]');
    admiralImgs.forEach(img => {
      let cur = img;
      while (cur && cur !== document.body) {
        if (looksLikeOverlay(cur) && !cur.getAttribute('data-vadblock-hidden')) {
          hideWall(cur);
          return;
        }
        cur = cur.parentElement;
      }
    });

    // 2. Metin tabanlı tespit — güçlü duvar ifadesi + overlay görünümü şartı
    const elements = document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, span, div, button');
    const viewportArea = window.innerWidth * window.innerHeight;
    elements.forEach(el => {
      if (el.children.length > 3) return;
      const text = (el.innerText || el.textContent || '').toLowerCase();
      if (!STRONG_WALL.test(text)) return;

      // Element duvar gibi görünmüyorsa ve metin küçük bir öğeyse atla
      const rect = el.getBoundingClientRect();
      const area = rect.width * rect.height;
      if (area < viewportArea * 0.04) return;

      const target = findWallTarget(el);
      if (target) {
        const tRect = target.getBoundingClientRect();
        // Aşırı yanlış pozitife karşı: hedef görünümün %85'inden büyükse gizleme
        if (tRect.width * tRect.height < viewportArea * 0.85) {
          hideWall(target);
        }
      }
    });
  }

  const observer = new MutationObserver(() => {
    const now = Date.now();
    if (window.__vadblockLastScan && now - window.__vadblockLastScan < 800) return;
    window.__vadblockLastScan = now;
    scan();
  });

  function start() {
    scan();
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
