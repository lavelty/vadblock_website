﻿// cookie_rejector.js - Akıllı Çerez Uyarı Reddedici
(() => {
    'use strict';
    if (window.__vadCookieRejectorActive) return;
    window.__vadCookieRejectorActive = true;

    const keywords = ['reject all', 'decline', 'deny', 'tümünü reddet', 'kabul etmiyorum', 'yalnızca gerekli', 'only necessary', 'necessary only', 'refuse'];
    
    function tryReject() {
        const candidates = document.querySelectorAll('button, a, [role="button"], div[class*="button"]');
        for (const el of candidates) {
            const text = (el.innerText || el.textContent || '').trim().toLowerCase();
            if (!text || text.length > 30) continue; 
            
            for (const k of keywords) {
                if (text === k || text.includes(k)) {
                    // Make sure it doesn't also say 'accept'
                    if (text.includes('accept') || text.includes('kabul et') || text.includes('allow')) {
                        continue;
                    }
                    if (el.offsetParent !== null) {
                        el.click();
                        console.log('[vAdBlock] Cookie popup rejected.');
                        return true;
                    }
                }
            }
        }
        return false;
    }

    let attempts = 0;
    const interval = setInterval(() => {
        if (tryReject() || attempts > 10) {
            clearInterval(interval);
        }
        attempts++;
    }, 500);
})();
